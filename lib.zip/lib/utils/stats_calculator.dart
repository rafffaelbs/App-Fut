import 'package:collection/collection.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'player_identity.dart';
import 'rating_calculator.dart';

import '../models/match_model.dart';
import '../models/match_lineup_model.dart';
import '../repositories/matches_repository.dart';
import '../repositories/players_repository.dart';

/// Utility to aggregate a group's entire match history.
Future<List<dynamic>> getAllGroupMatches(String groupId) async {
  try {
    final matchesRepo = MatchesRepository();
    // getMatchesByGroup não traz mais o objeto completo do jogador dentro de
    // cada escalação (isso duplicava um payload enorme). Por isso buscamos
    // os nomes aqui, à parte -- é uma consulta leve (1 linha por jogador do
    // grupo) e já é cacheada pelo PlayersRepository.
    final results = await Future.wait([
      matchesRepo.getMatchesByGroup(groupId),
      PlayersRepository().getPlayersByGroup(groupId),
    ]);
    final matches = results[0] as List<MatchModel>;
    final players = results[1] as List<dynamic>;
    final Map<String, String> namesById = {
      for (final p in players) p.id.toString(): p.name.toString(),
    };

    if (matches.isNotEmpty) {
      final List<dynamic> allHistory = matches.map((MatchModel m) {
        final List<MatchLineupModel> lineups = m.lineups;
        final events = m.events;
        String nameFor(String playerId, dynamic player) =>
            player?.name ?? namesById[playerId] ?? playerId;
        return {
          'id': m.id,
          'sessionId': m.sessionId,
          'scoreRed': m.teamAScore,
          'scoreWhite': m.teamBScore,
          'session_date': m.startTime?.toIso8601String() ?? m.timestamp.toIso8601String(),
          'date': m.startTime?.toIso8601String() ?? m.timestamp.toIso8601String(),
          'events': events.map((ev) => {
            'player': ev.playerId,
            'playerId': ev.playerId,
            'assist': ev.assistPlayerId ?? '',
            'assistId': ev.assistPlayerId ?? '',
            'type': ev.eventType,
            'time': ev.team ?? '',
            'minute': ev.minute,
          }).toList(),
          'players': {
            'red': lineups.where((l) => l.isTeamA && !l.isGoalkeeper).map((l) => {
              'id': l.playerId,
              'name': nameFor(l.playerId, l.player),
              'icon': l.player?.avatarUrl,
            }).toList(),
            'white': lineups.where((l) => l.isTeamB && !l.isGoalkeeper).map((l) => {
              'id': l.playerId,
              'name': nameFor(l.playerId, l.player),
              'icon': l.player?.avatarUrl,
            }).toList(),
            'gk_red': lineups.where((l) => l.isTeamA && l.isGoalkeeper).map((l) => {
              'id': l.playerId,
              'name': nameFor(l.playerId, l.player),
              'icon': l.player?.avatarUrl,
            }).firstOrNull,
            'gk_white': lineups.where((l) => l.isTeamB && l.isGoalkeeper).map((l) => {
              'id': l.playerId,
              'name': nameFor(l.playerId, l.player),
              'icon': l.player?.avatarUrl,
            }).firstOrNull,
          },
          'isExactCurrentSeason': true,
        };
      }).toList();

      allHistory.sort((a, b) {
        String dateA = (a as Map)['session_date'] ?? a['date'] ?? '';
        String dateB = (b as Map)['session_date'] ?? b['date'] ?? '';
        return dateA.compareTo(dateB);
      });
      return allHistory;
    }
    // ignore: avoid_print
    print('getAllGroupMatches($groupId): getMatchesByGroup returned 0 matches (no error thrown).');
  } catch (e) {
    // Antes isso caía em silêncio pro fallback local (tela toda zerada,
    // "Estreante" pra todo mundo) sem nenhuma pista do motivo real.
    // ignore: avoid_print
    print('getAllGroupMatches($groupId) failed, falling back to local cache: $e');
  }

  // Fallback para SharedPreferences caso esteja offline ou local
  final prefs = await SharedPreferences.getInstance();
  final String sessionsKey = 'sessions_$groupId';
  final List<dynamic> allHistory = [];

  if (prefs.containsKey(sessionsKey)) {
    final List<dynamic> sessions = jsonDecode(prefs.getString(sessionsKey)!);
    for (final session in sessions) {
      final String? tId = session['id'];
      final String? sessionTimestamp = session['timestamp'];
      if (tId == null) continue;

      final String historyKey = 'match_history_$tId';
      if (!prefs.containsKey(historyKey)) continue;

      final List<dynamic> history = jsonDecode(prefs.getString(historyKey)!);
      if (sessionTimestamp != null) {
        for (final match in history) {
          if (match is Map) {
            match['session_date'] = sessionTimestamp;
          }
        }
      }
      allHistory.addAll(history);
    }
  }

  // Logic to filter ONLY the current season
  final String seasonsConfigKey = 'seasons_$groupId';
  if (prefs.containsKey(seasonsConfigKey)) {
    final List<dynamic> seasonsConfig = jsonDecode(prefs.getString(seasonsConfigKey)!);
    final now = DateTime.now();
    String? currentTemporadaId;
    
    for (var season in seasonsConfig) {
      if (season['startDate'] == null || season['endDate'] == null) continue;
      try {
        DateTime start = DateTime.parse(season['startDate']);
        DateTime end = DateTime.parse(season['endDate']).add(const Duration(days: 1));
        if (now.isAfter(start.subtract(const Duration(seconds: 1))) && now.isBefore(end)) {
          currentTemporadaId = (season['isPreSeason'] == true && season['parentSeasonId'] != null)
              ? season['parentSeasonId']
              : season['id'];
          break;
        }
      } catch (_) {}
    }

    if (currentTemporadaId == null && seasonsConfig.isNotEmpty) {
      currentTemporadaId = seasonsConfig[0]['id'];
    }

    if (currentTemporadaId != null) {
      String exactCurrentSeasonId = '';
      for (var season in seasonsConfig) {
        if (season['startDate'] == null || season['endDate'] == null) continue;
        try {
          DateTime start = DateTime.parse(season['startDate']);
          DateTime end = DateTime.parse(season['endDate']).add(const Duration(days: 1));
          if (now.isAfter(start.subtract(const Duration(seconds: 1))) && now.isBefore(end)) {
            exactCurrentSeasonId = season['id'];
            break;
          }
        } catch (_) {}
      }
      if (exactCurrentSeasonId.isEmpty && seasonsConfig.isNotEmpty) {
        exactCurrentSeasonId = seasonsConfig[0]['id'];
      }

      final filtered = allHistory.where((match) {
        String sessionDate = match['session_date'] ?? match['date'] ?? '';
        if (sessionDate.isEmpty) return false;
        try {
          DateTime dt = DateTime.parse(sessionDate);
          for (var season in seasonsConfig) {
            if (season['startDate'] == null || season['endDate'] == null) continue;
            DateTime start = DateTime.parse(season['startDate']);
            DateTime end = DateTime.parse(season['endDate']).add(const Duration(days: 1));
            if (dt.isAfter(start.subtract(const Duration(seconds: 1))) && dt.isBefore(end)) {
              String sId = (season['isPreSeason'] == true && season['parentSeasonId'] != null)
                  ? season['parentSeasonId']
                  : season['id'];
              if (sId == currentTemporadaId) {
                if (match is Map) {
                  match['isPreSeasonMatch'] = season['isPreSeason'] == true;
                  match['isExactCurrentSeason'] = season['id'] == exactCurrentSeasonId;
                }
                return true;
              }
            }
          }
        } catch (_) {}
        return false;
      }).toList();

      filtered.sort((a, b) {
        String dateA = (a as Map)['session_date'] ?? a['date'] ?? '';
        String dateB = (b as Map)['session_date'] ?? b['date'] ?? '';
        return dateA.compareTo(dateB);
      });
      return filtered;
    }
  }

  allHistory.sort((a, b) {
    String dateA = (a as Map)['session_date'] ?? a['date'] ?? '';
    String dateB = (b as Map)['session_date'] ?? b['date'] ?? '';
    return dateA.compareTo(dateB);
  });
  return allHistory;
}

/// Processes every match and returns a Map with the global stats for each playerId
/// Map<String, Map<String, dynamic>> where the key is the playerId.
Map<String, Map<String, dynamic>> calculateGlobalStats(List<dynamic> allHistory) {
  final Map<String, Map<String, dynamic>> globalStats = {};

  for (final match in allHistory) {
    if (match is! Map) continue;
    final int scoreRed = match['scoreRed'] ?? 0;
    final int scoreWhite = match['scoreWhite'] ?? 0;
    final int redStatus = scoreRed > scoreWhite ? 1 : (scoreRed == scoreWhite ? 0 : -1);
    final int whiteStatus = scoreWhite > scoreRed ? 1 : (scoreRed == scoreWhite ? 0 : -1);

    // Collect events per player in this match
    final Map<String, Map<String, int>> matchPlayerEvents = {};
    if (match['events'] != null) {
      for (final ev in match['events']) {
        if (ev is! Map) continue;
        final String pid = eventPlayerId(ev, 'player');
        final String astId = eventPlayerId(ev, 'assist');
        final String type = ev['type'];

        if (pid.isNotEmpty) {
          matchPlayerEvents.putIfAbsent(pid, () => {'g': 0, 'a': 0, 'og': 0, 'yc': 0, 'rc': 0});
          if (type == 'goal') matchPlayerEvents[pid]!['g'] = matchPlayerEvents[pid]!['g']! + 1;
          if (type == 'own_goal') matchPlayerEvents[pid]!['og'] = matchPlayerEvents[pid]!['og']! + 1;
          if (type == 'yellow_card') matchPlayerEvents[pid]!['yc'] = matchPlayerEvents[pid]!['yc']! + 1;
          if (type == 'red_card') matchPlayerEvents[pid]!['rc'] = matchPlayerEvents[pid]!['rc']! + 1;
        }
        if (astId.isNotEmpty) {
          matchPlayerEvents.putIfAbsent(astId, () => {'g': 0, 'a': 0, 'og': 0, 'yc': 0, 'rc': 0});
          if (type == 'goal') matchPlayerEvents[astId]!['a'] = matchPlayerEvents[astId]!['a']! + 1;
        }
      }
    }

    final Set<String> processed = {};
    
    // Calculates team averages based on the ratings so far
    final List<dynamic> redField = List<dynamic>.from(match['players']?['red'] ?? []);
    final dynamic gkRed = match['players']?['gk_red'];
    final List<dynamic> redPlayers = [...redField, gkRed].where((p) => p != null).toList();
    
    final List<dynamic> whiteField = List<dynamic>.from(match['players']?['white'] ?? []);
    final dynamic gkWhite = match['players']?['gk_white'];
    final List<dynamic> whitePlayers = [...whiteField, gkWhite].where((p) => p != null).toList();
    
    double redSum = 0; int redCount = 0;
    for (var p in redPlayers) {
      String pid = playerIdFromObject(p);
      if (pid.isNotEmpty && globalStats.containsKey(pid)) {
        redSum += calculateFinalRating(ratings: globalStats[pid]!['ratings'] as List<double>);
        redCount++;
      }
    }
    double redAvg = redCount > 0 ? redSum / redCount : kRatingBase;

    double whiteSum = 0; int whiteCount = 0;
    for (var p in whitePlayers) {
      String pid = playerIdFromObject(p);
      if (pid.isNotEmpty && globalStats.containsKey(pid)) {
        whiteSum += calculateFinalRating(ratings: globalStats[pid]!['ratings'] as List<double>);
        whiteCount++;
      }
    }
    double whiteAvg = whiteCount > 0 ? whiteSum / whiteCount : kRatingBase;

    void processPlayer(dynamic playerObj, int status, int scored, int conceded, double teamAvg, double oppAvg) {
      if (playerObj == null) return;
      final String playerId = playerIdFromObject(playerObj);
      if (playerId.isEmpty || processed.contains(playerId)) return;
      processed.add(playerId);

      globalStats.putIfAbsent(playerId, () => {
        'id': playerId,
        'games': 0, 'wins': 0, 'draws': 0, 'losses': 0,
        'goals': 0, 'assists': 0, 'yellow': 0, 'red': 0, 'ratings': <double>[],
        'name': (playerObj['name'] ?? '').toString()
      });
      
      final Map<String, dynamic> playerStats = globalStats[playerId]!;
      
      final int g = matchPlayerEvents[playerId]?['g'] ?? 0;
      final int a = matchPlayerEvents[playerId]?['a'] ?? 0;
      final int og = matchPlayerEvents[playerId]?['og'] ?? 0;
      final int yc = matchPlayerEvents[playerId]?['yc'] ?? 0;
      final int rc = matchPlayerEvents[playerId]?['rc'] ?? 0;

      if (match['isExactCurrentSeason'] == true || match['isExactCurrentSeason'] == null) {
        playerStats['games'] = (playerStats['games'] as int) + 1;
        
        if (status == 1) playerStats['wins'] = (playerStats['wins'] as int) + 1;
        else if (status == -1) playerStats['losses'] = (playerStats['losses'] as int) + 1;
        else playerStats['draws'] = (playerStats['draws'] as int) + 1;

        playerStats['goals'] = (playerStats['goals'] as int) + g;
        playerStats['assists'] = (playerStats['assists'] as int) + a;
        playerStats['yellow'] = (playerStats['yellow'] as int) + yc;
        playerStats['red'] = (playerStats['red'] as int) + rc;
      }

      final double matchRating = calculateMatchRating(
        status: status, goals: g, assists: a,
        ownGoals: og, teamGoals: scored, conceded: conceded, yellow: yc, red: rc,
        teamWinStreak: 0, teamAvgRating: teamAvg, opponentAvgRating: oppAvg
      );
      (playerStats['ratings'] as List<double>).add(matchRating);
    }

    if (match['players'] != null && match['players'] is Map) {
      if (match['players']['red'] != null) {
        for (final p in match['players']['red']) processPlayer(p, redStatus, scoreRed, scoreWhite, redAvg, whiteAvg);
      }
      if (match['players']['white'] != null) {
        for (final p in match['players']['white']) processPlayer(p, whiteStatus, scoreWhite, scoreRed, whiteAvg, redAvg);
      }
      if (match['players']['gk_red'] != null) processPlayer(match['players']['gk_red'], redStatus, scoreRed, scoreWhite, redAvg, whiteAvg);
      if (match['players']['gk_white'] != null) processPlayer(match['players']['gk_white'], whiteStatus, scoreWhite, scoreRed, whiteAvg, redAvg);
    }
  }

  // Precomputes the final rating (already using the math rules defined in rating_calculator)
  globalStats.forEach((id, data) {
    data['nota'] = calculateFinalRating(ratings: data['ratings'] as List<double>);
    data['ga'] = (data['goals'] as int) + (data['assists'] as int);
  });

  return globalStats;
}
